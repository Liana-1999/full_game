﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NextLevelMenu : MonoBehaviour {

    public int MaxBuildIndexForThisGame;
    public sceneFader fader;
    public string levelToFade;
    public Text stateText;

    void Start()
    {
        stateText.enabled = false;
    }

	public void NextLevel()
    {
        if (SceneManager.GetActiveScene().buildIndex == MaxBuildIndexForThisGame)
        {
            stateText.enabled = true;
            stateText.text = "All Levels Cleared";
        }
        else
        {
            fader.FadeTo(levelToFade);
           
        }

    }
    public void Menu()
    {
        fader.FadeTo("menu_Matchstick");
    }
}
