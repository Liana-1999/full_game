﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class levelSelection : MonoBehaviour {

    public enum gameType { Pentomino, Matchstick };

    public Button[] lvlButtons;
    public gameType type = gameType.Pentomino;
    int levelOnePassed;

    void Start()
    {
        if (type == gameType.Matchstick)
        {
            int levelAt = PlayerPrefs.GetInt("levelAt_Matchstick", 2);
            levelOnePassed = PlayerPrefs.GetInt("LevelOnePassed_Matchstick");
            for (int i = 0; i < lvlButtons.Length; i++)
            {
                if (levelOnePassed == 0)
                {
                    if (i + 2 > levelAt)
                        lvlButtons[i].interactable = false;
                }
                else
                {
                    if (i + 3 > levelAt)
                        lvlButtons[i].interactable = false;
                }
            }
        }
        else
        {
            int levelAt = PlayerPrefs.GetInt("levelAt_Pentomino", 2);
            levelOnePassed = PlayerPrefs.GetInt("LevelOnePassed_Pentomino");
            for (int i = 0; i < lvlButtons.Length; i++)
            {
                if (levelOnePassed == 0)
                {

                    if (i + 2 > levelAt)
                        lvlButtons[i].interactable = false;
                }
                else
                {
                    if (i + 10 > levelAt)
                        lvlButtons[i].interactable = false;
                }
                
            }
        }
    }

}
