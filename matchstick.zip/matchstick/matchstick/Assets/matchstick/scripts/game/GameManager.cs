﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour {

    public static int index = 0;
    public int threshold;
    public GameObject nextLevelMenu;
    int nextSceneLoad;
    int secondLevel = 4;


    void Start()
    {
        nextSceneLoad = SceneManager.GetActiveScene().buildIndex + 1;
        nextLevelMenu.SetActive(false);
    }

    void Update()
    {
        if (index == threshold)
        {
            nextLevelMenu.SetActive(true);
            index = 0;
            if (nextSceneLoad > PlayerPrefs.GetInt("levelAt_Matchstick"))
            {
                PlayerPrefs.SetInt("levelAt_Matchstick", nextSceneLoad);
            }

            if (nextSceneLoad == secondLevel)
            {
                PlayerPrefs.SetInt("levelAt_Matchstick", nextSceneLoad);
                PlayerPrefs.SetInt("LevelOnePassed_Matchstick", secondLevel);
            }
        }
    }
}
