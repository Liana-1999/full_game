﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameInfo : MonoBehaviour {

    public static int index = 0;
    public GameObject nextLevelMenu;
    int nextSceneLoad;
    int secondLevel = 11;


    void Start()
    {
        nextSceneLoad = SceneManager.GetActiveScene().buildIndex + 1;
        nextLevelMenu.SetActive(false);
    }

    void Update()
    {
        if(index == 12)
        {
            nextLevelMenu.SetActive(true);
            index = 0;
            if (nextSceneLoad > PlayerPrefs.GetInt("levelAt_Pentomino"))
            {
                PlayerPrefs.SetInt("levelAt_Pentomino", nextSceneLoad);
            }

            if (nextSceneLoad == secondLevel)
            {
                PlayerPrefs.SetInt("levelAt_Pentomino", nextSceneLoad);
                PlayerPrefs.SetInt("LevelOnePassed_Pentomino", secondLevel);
            }
        }
    }
}
